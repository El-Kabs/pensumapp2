import json
data = json.load(open('merge.json'))

def hacerArchivo(llave, valor, contador):
    nombreArchivo = 'materia'+str(i)
    with open(nombreArchivo+'.json', 'w') as outfile:
        json.dump({llave:valor}, outfile, indent=4)
        
i = 0
for x in data[0]:
    llave = x
    valor = data[0][llave]
    hacerArchivo(llave, valor, i)
    i+=1


